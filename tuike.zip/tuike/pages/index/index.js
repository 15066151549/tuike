//index.js
//获取应用实例
const app = getApp()

Page({
  data: {
    // motto: 'Hello World',
    userInfo: {},
    hasUserInfo: false,
    canIUse: wx.canIUse('button.open-type.getUserInfo'),
    region: [],
    // 轮播
    current: 0,
    circular: true,
    autoplay: true,
    interval: 3000,
    duration: 500,
    indicatorDots: false,
    background: ['demo-text-1', 'demo-text-2', 'demo-text-3'], // 轮播
    recomendList: [{
      src: "./../../images/ceshi1.png",
      name: "团队套餐1",
      sucNum: 2221,
      proficua: "500.00",
      maxNum: 19,
      minNum: 12,
      headList: ["./../../images/ceshi1.png", "./../../images/ceshi2.png"]
    }, {
      src: "./../../images/ceshi1.png",
      name: "团队套餐2",
      sucNum: 999,
      proficua: "520.00",
      maxNum: 19,
      minNum: 11,
      headList: ["./../../images/ceshi1.png", "./../../images/ceshi2.png", "./../../images/ceshi1.png", "./../../images/ceshi2.png"]
    }, {
      src: "./../../images/ceshi1.png",
      sucNum: 15551,
      name: "团队套餐3",
      proficua: "540.00",
      maxNum: 91,
      minNum: 11,
      headList: ["./../../images/ceshi1.png", "./../../images/ceshi2.png", "./../../images/ceshi1.png", "./../../images/ceshi2.png"]
    }],
    where: {
      page: 1,
      limit: 6,
    },
    video: {
      playing: false,
      autoplay: false,
      controls: false,
      showFullscreenBtn: false,
      showPlayBtn: false,
      showCenterPlayBtn: true,
      enableProgressGesture: false,
      objectFit: "fill",
      muted: true,
      playBtnPosition: "center",
    },
    msgList: [{
        cashNum: 201, //提现会员号
        cashMoney: 1000, //提现金额
      },
      {
        cashNum: 202, //提现会员号
        cashMoney: 555500, //提现金额
      },
      {
        cashNum: 2044, //提现会员号
        cashMoney: 990, //提现金额
      }
    ],
    headList: [1, 2, 3, 4],
    serverList: [
    ],
    videoSrc: "https://ms.gaoruankeji.com/public/uploads/store/video/20190619/5d09a235a5560.mp4",
  },
  //事件处理函数
  bindViewTap: function() {
    wx.navigateTo({
      url: '../logs/logs'
    })
  },
  onLoad: function() {
    if (app.globalData.userInfo) {
      this.setData({
        userInfo: app.globalData.userInfo,
        hasUserInfo: true
      })
    } else if (this.data.canIUse) {
      // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
      // 所以此处加入 callback 以防止这种情况
      app.userInfoReadyCallback = res => {
        this.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
      }
    } else {
      // 在没有 open-type=getUserInfo 版本的兼容处理
      wx.getUserInfo({
        success: res => {
          app.globalData.userInfo = res.userInfo
          this.setData({
            userInfo: res.userInfo,
            hasUserInfo: true
          })
        }
      })
    }
  },
  onShow: function() {
    this.getServerList();
    // this.getSeats();
  },
  getServerList: function() {
    var server = this.data.serverList;
    var res = [{
        name: "商品1111111",
        videoSrc: "https://ms.gaoruankeji.com/public/uploads/store/video/20190619/5d09a235a5560.mp4",
        src: "./../../images/ceshi2.png",
        poster: "https://ms.gaoruankeji.com/public/uploads/attach/2019/07/13/5d2992a63255e.jpg",
        userName: "名字11111111",
        loved: false,
        loveNum: 121,
        type: 1,
      },
      {
        name: "商品2222",
        videoSrc: "https://ms.gaoruankeji.com/public/uploads/store/video/20190619/5d09a235a5560.mp4",
        src: "./../../images/ceshi2.png",
        poster: "https://ms.gaoruankeji.com/public/uploads/attach/2019/07/13/5d2992a63255e.jpg",
        userName: "名字11122",
        loved: true,
        loveNum: 1222,
        type: 2,
      },
      {
        name: "商品1333",
        videoSrc: "https://ms.gaoruankeji.com/public/uploads/store/video/20190619/5d09a235a5560.mp4",
        src: "./../../images/ceshi2.png",
        poster: "https://ms.gaoruankeji.com/public/uploads/attach/2019/07/13/5d2992a63255e.jpg",
        userName: "名字13331",
        loved: true,
        loveNum: 133,
        type: 3,
      },
      {
        name: "商品1144444",
        videoSrc: "https://ms.gaoruankeji.com/public/uploads/store/video/20190619/5d09a235a5560.mp4",
        src: "./../../images/ceshi2.png",
        poster: "https://ms.gaoruankeji.com/public/uploads/attach/2019/07/13/5d2992a63255e.jpg",
        userName: "名字1444411",
        loved: true,
        loveNum: 1444,
        type: 3,
      },
      {
        name: "商品1155",
        videoSrc: "https://ms.gaoruankeji.com/public/uploads/store/video/20190619/5d09a235a5560.mp4",
        src: "./../../images/ceshi2.png",
        poster: "https://ms.gaoruankeji.com/public/uploads/attach/2019/07/13/5d2992a63255e.jpg",
        userName: "名字1155",
        loved: true,
        loveNum: 1555,
        type: 2,
      },
      {
        name: "商品1666",
        videoSrc: "https://ms.gaoruankeji.com/public/uploads/store/video/20190619/5d09a235a5560.mp4",
        src: "./../../images/ceshi2.png",
        poster: "https://ms.gaoruankeji.com/public/uploads/attach/2019/07/13/5d2992a63255e.jpg",
        userName: "名字11666",
        loved: true,
        loveNum: 1666,
        type: 1,
      }
    ];
    for(var i = 0 ; i<res.length;i++){
    server.push(res[i]);
    }
    this.setData({
      serverList:server,
    })
  },
  getUserInfo: function(e) {
    console.log(e)
    app.globalData.userInfo = e.detail.userInfo
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  },
  bindRegionChange: function(e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      region: e.detail.value[2],
    })

  },
  getSeats: function() {
    wx.getLocation({
      type: 'gcj02',
      success(res) {
        const latitude = res.latitude
        const longitude = res.longitude
        const speed = res.speed
        const accuracy = res.accuracy
        console.log(res);
      }
    })

  },
  // 轮播图点
  swiperChange: function(e) {
    // console.log(e.detail.current);
    this.setData({
      current: e.detail.current
    });
  },
  // 视频
  onVideoPlay: function() {
    if (this.data.video.playing == true) {
      console.log(11111);
    } else {
      this.setData({
        ['video.playing']: true,
      })
    }

  },
  videoPause: function() {

    this.setData({
      ['video.playing']: false,
    })

  },
  videoEnd: function() {

    this.setData({
      ['video.playing']: false,
    })

  },

  // 页面上拉触底事件的处理函数
  onReachBottom: function() {
    this.getServerList();
    console.log("daodi");

  },
})